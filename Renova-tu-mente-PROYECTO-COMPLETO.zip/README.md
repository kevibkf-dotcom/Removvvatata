# Renova tu mente — v2.0

Aplicación Android offline de apoyo para disciplina personal, lectura bíblica, reflexión, seguimiento de hábitos y motivación para entrenar.

## Funciones
- Biblioteca bíblica offline con más de 100 pasajes seleccionados de la Reina-Valera 1909 (texto de dominio público).
- Búsqueda por texto, referencia, categoría y tema.
- Jesús, Dios, Mente, Disciplina, Tentación, Pureza, Fortaleza, Esperanza y otros temas.
- Versículo diario.
- Calendario mensual de progreso.
- Racha y días logrados guardados localmente.
- Modo emergencia para momentos de tentación.
- Motivaciones originales.
- Sección Gym y disciplina.
- Reflexiones prácticas.
- Sin servidor, sin cuenta y sin Internet para el contenido.
- GitHub Actions para generar APK Debug.

## GitHub
Sube **el contenido de este proyecto**, manteniendo `.github/workflows/build-apk.yml`.

Después:
Actions → Compilar APK Renova tu mente sin conexión → Run workflow.

El artefacto se llama `Renova-tu-mente-APK-sin-conexion`.

## Nota
La app es una herramienta de apoyo y no sustituye atención profesional ni acompañamiento pastoral. Si una conducta se vuelve compulsiva o te genera sufrimiento importante, hablar con un profesional o persona de confianza puede ser útil.
